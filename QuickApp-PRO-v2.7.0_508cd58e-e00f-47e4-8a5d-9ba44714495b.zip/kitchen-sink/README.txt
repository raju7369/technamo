The kitchen-sink contains extra code for walk-throughs and other domain specific implementations

Extra Contents
******************
* Configure IdentityServer to use EntityFramework Core with SQL Server as the storage mechanism (Instead of in-memory)












NOTE: You can do a diff of the two project folders to see how they differ